"""
Templatetags module for tagging.
"""
