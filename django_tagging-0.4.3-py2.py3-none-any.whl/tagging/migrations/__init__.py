"""
Migrations for tagging.
"""
